alert('Assalomu alekum. Saytimizga xush kelibsiz');

// console.log('Proweb');

var str = prompt('Ismingizni kiriting');
console.log(str);
alert('Salom ' + str + ('. Saytga kirishingiz uchun ma`lumotlarni to`ldiring!'));

var num = +prompt(str + ' yoshingizni kiriting!');
console.log(num);

